﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App.DtoModel
{
    public class DoctorModel
    {
        public string Dr_ID { get; set; }
        public string Dr_Name { get; set; }
       
    }

    public class DropDrownModel
    {
        public string ID { get; set; }
        public string Name { get; set; }

    }
}
